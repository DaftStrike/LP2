﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulos
{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            try
            {
                LadoA  = Convert.ToDouble(txtLadoB.Text);
            }
            catch
            {
                MessageBox.Show("Lado deve ser um número!");
                txtLadoB.Focus();
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            try
            {
                LadoB = Convert.ToDouble(txtLadoA.Text);
            }
            catch
            {
                MessageBox.Show("Lado deve ser um número!");
                txtLadoA.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            try
            {
                LadoC = Convert.ToDouble(txtLadoC.Text);
            }
            catch
            {
                MessageBox.Show("Lado deve ser um número!");
                txtLadoC.Focus();
            }
        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
            if((Math.Abs(LadoB - LadoC) < LadoA && LadoA < LadoB + LadoC) && //Lado A
                (Math.Abs(LadoA - LadoC) < LadoB && LadoB < LadoA + LadoC) && //Lado B
                (Math.Abs(LadoA - LadoB) < LadoC && LadoC < LadoA + LadoB)) //Lado C
            {
                if (LadoA == LadoB && LadoB == LadoC)
                    txtResultado.Text = "Equilátero";
                else if ((LadoA == LadoB) || (LadoA == LadoC) || (LadoB == LadoC))
                    txtResultado.Text = "Isóceles";
                else
                    txtResultado.Text = "Escaleno";
            }
            else
            {
                txtResultado.Text = "Inexistente";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoB.Clear();
            txtLadoA.Clear();
            txtLadoC.Clear();
            txtResultado.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
