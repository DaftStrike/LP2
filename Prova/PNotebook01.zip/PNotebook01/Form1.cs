﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[] media = new double[4];
            double[,] precNotes = new double[3, 3];
            string auxiliar = "";

            for (int note = 0; note < 3; note++)
            {
                for (int loja = 0; loja < 3; loja++)
                {
                    auxiliar = Interaction.InputBox($"Digite o preço na {loja + 1}a loja:", $"Notebook {note + 1}");

                    if (!Double.TryParse(auxiliar, out precNotes[note, loja]) || precNotes[note, loja] <= 0)
                    {
                        MessageBox.Show("Valor Inválido!");
                        loja--;
                    }
                    else
                    {
                        media[note] += precNotes[note, loja];
                    }
                }
                media[note] /= 3;
            }
            media[3] = (media[0] + media[1] + media[2])/3;
            lstbxPCs.Items.Add($"Notebook 1 Loja 1: R${precNotes[0,0]}  Loja 2: R${precNotes[0, 1]}  Loja 3: R${precNotes[0, 2]}  Média: R${media[0]}");
            lstbxPCs.Items.Add($"Notebook 2 Loja 1: R${precNotes[1, 0]}  Loja 2: R${precNotes[1, 1]}  Loja 3: R${precNotes[1, 2]}  Média: R${media[1]}");
            lstbxPCs.Items.Add($"Notebook 3 Loja 1: R${precNotes[2, 0]}  Loja 2: R${precNotes[2, 1]}  Loja 3: R${precNotes[2, 2]}  Média: R${media[2]}");
            lstbxPCs.Items.Add("---------------------------------------");
            lstbxPCs.Items.Add($"Média Geral dos Computadores: R${Math.Round(media[3], 2)}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxPCs.Items.Clear();
        }
    }
}
