﻿namespace PContato0030482511012
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.rtbxSobre = new System.Windows.Forms.RichTextBox();
            this.pcbxImagem = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pcbxImagem)).BeginInit();
            this.SuspendLayout();
            // 
            // rtbxSobre
            // 
            this.rtbxSobre.Enabled = false;
            this.rtbxSobre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.rtbxSobre.Location = new System.Drawing.Point(249, 175);
            this.rtbxSobre.Name = "rtbxSobre";
            this.rtbxSobre.Size = new System.Drawing.Size(694, 400);
            this.rtbxSobre.TabIndex = 0;
            this.rtbxSobre.Text = resources.GetString("rtbxSobre.Text");
            // 
            // pcbxImagem
            // 
            this.pcbxImagem.Image = ((System.Drawing.Image)(resources.GetObject("pcbxImagem.Image")));
            this.pcbxImagem.Location = new System.Drawing.Point(949, 175);
            this.pcbxImagem.Name = "pcbxImagem";
            this.pcbxImagem.Size = new System.Drawing.Size(681, 400);
            this.pcbxImagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pcbxImagem.TabIndex = 1;
            this.pcbxImagem.TabStop = false;
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1898, 1024);
            this.Controls.Add(this.pcbxImagem);
            this.Controls.Add(this.rtbxSobre);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            ((System.ComponentModel.ISupportInitialize)(this.pcbxImagem)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbxSobre;
        private System.Windows.Forms.PictureBox pcbxImagem;
    }
}