﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double Peso, Altura, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskPeso.Clear();
            mskAltura.Clear();
            txtIMC.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Peso > 0 && Altura > 0)
            {
                IMC = Peso / Math.Pow(Altura, 2);
                IMC = Math.Round(IMC, 1);

                if (IMC < 18.5)
                {
                    txtIMC.Text = IMC.ToString();
                    MessageBox.Show("Magreza");
                }
                else if (IMC <= 24.9)
                {
                    txtIMC.Text = IMC.ToString();
                    MessageBox.Show("Normal");
                }
                else if (IMC <= 29.9)
                {
                    txtIMC.Text = IMC.ToString();
                    MessageBox.Show("Sobrepeso");
                }
                else if (IMC <= 39.9)
                {
                    txtIMC.Text = IMC.ToString();
                    MessageBox.Show("Obesidade");
                }
                else
                {
                    txtIMC.Text = IMC.ToString();
                    MessageBox.Show("Obesidade Grave");
                }
            }
        }

        private void mskPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(mskPeso.Text, out Peso) || Peso <= 0)
            {
                MessageBox.Show("Peso inválido!");
            }
        }
        private void mskAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(mskAltura.Text, out Altura) || Altura <= 0)
            {
                MessageBox.Show("Altura inválida!");
            }
        }
    }
}
